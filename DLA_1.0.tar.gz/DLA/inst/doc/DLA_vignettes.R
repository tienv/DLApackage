## ----loadlib-------------------------------------------------------------
library(DLA)
data(LabelArrayExample)

## ------------------------------------------------------------------------
dim(LabelArrayExample)

## ---- eval=FALSE---------------------------------------------------------
#  DisplayLabArr(label.array=LabelArrayExample, bg.index = bg.index,
#  foldername="Images", filename_pre="Image")

